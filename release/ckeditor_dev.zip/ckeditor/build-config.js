﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
var CKBUILDER_CONFIG={skin:"none",preset:"basic",ignore:".bender bender.js bender-err.log bender-out.log dev .DS_Store .editorconfig .gitattributes .gitignore gruntfile.js .idea .jscsrc .jshintignore .jshintrc less .mailmap node_modules package.json README.md tests".split(" "),plugins:{SimpleLink:1,sharedspace:1,floatingspace:1,dialogui:1,blockquote:1,dialog:1,basicstyles:1,clipboard:1,divarea:1,enterkey:1,entities:1,indent:1,indentlist:1,list:1,toolbar:1,undo:1,button:1},languages:{en:1}};